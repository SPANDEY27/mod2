package com.ui;
import com.bean.*;
import com.utility.*;
import java.util.*;
public class UserInterface {
	public static void main(String[] args)
	{
		//Fill the code
	}
	

}
