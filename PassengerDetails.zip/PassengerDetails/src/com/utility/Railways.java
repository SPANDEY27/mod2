package com.utility;
import com.bean.*;
import java.util.*;

public class Railways {

	private List<Passenger> passengerList=new ArrayList<Passenger>();

	public List<Passenger> getPassengerList() {
		return passengerList;
	}

	public void setPassengerList(List<Passenger> passengerList) {
		this.passengerList = passengerList;
	}
	
	//This method should add the passenger in to the passengerList
	public void addPassenger(Passenger passenger)
	{
		
	}
	
	//This method should return the total number of passengers 
	//for the given gender
	public int countBasedOnGender(String gender)
	{
		return 0;
	}
	
}
