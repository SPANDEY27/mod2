import static org.junit.Assert.*;

import org.junit.Test;

public class EBBillTest {
	@Test
	public void testcalculatBill1() {
		EBBill obj1 = new EBBill(123, "arun", 101, 10);
		double actual = obj1.calculatBill();
		double expected = 10;
		assertTrue(expected == actual);

	}

	@Test
	public void testcalculatBill2() {
		EBBill obj2 = new EBBill(123, "arun", 90, 10);
		double actual = obj2.calculatBill();
		double expected = 0;
		assertTrue(expected == actual);

	}

}
