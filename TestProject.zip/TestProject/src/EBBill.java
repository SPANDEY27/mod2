public class EBBill {
	private int billNo;
	private String consumerName;
	private int unitsConsumed;
	private double perUnitCost;
	public EBBill(int billNo, String consumerName, int unitsConsumed, double perUnitCost) {
		super();
		this.billNo =billNo;
		this.consumerName =consumerName;
		this.unitsConsumed = unitsConsumed;
		this.perUnitCost = perUnitCost;
	}
	public double calculatBill(){
		if(unitsConsumed >=0 && unitsConsumed  <= 100){
			return 0;
		} else {
			unitsConsumed=unitsConsumed-100;
			return (unitsConsumed *perUnitCost);
		}
	}
	
}
