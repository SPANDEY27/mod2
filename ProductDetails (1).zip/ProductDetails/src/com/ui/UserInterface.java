package com.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.bean.Product;
import com.utility.Shop;

public class UserInterface {

	public static void main(String a[]) {
		int productsNumber = 0;
		Shop shop = new Shop();
		shop.setProductList(new ArrayList<Product>());
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of product");
		productsNumber = Integer.parseInt(sc.nextLine());

		for (int i = 0; i < productsNumber; i++) {
			Product product = new Product();
			System.out.println("Enter the product name");
			String pName = sc.nextLine();
			product.setProductName(pName);
			System.out.println("Enter the product category");
			String pCategory = sc.nextLine();
			product.setProductCategory(pCategory);
			System.out.println("Enter the product price");
			double productprice = Double.parseDouble(sc.nextLine());
			product.setProductPrice(productprice);
			shop.addProduct(product);
		}

		System.out.println("Product details after discount");
		List<Product> productList = shop.getProductList();
		for (Product product : productList) {
			System.out.println(product.getProductName() + " " + product.calculateDiscountedProductPrice());
		}

		System.out.println("Enter the product category to be searched");
		String searchCategory = sc.nextLine();
		System.out.println(shop.countBasedOnCategory(searchCategory));

	}

}
