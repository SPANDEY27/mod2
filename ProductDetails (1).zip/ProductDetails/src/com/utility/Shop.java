package com.utility;

import java.util.ArrayList;
import java.util.List;

import com.bean.*;

public class Shop {

	private List<Product> productList = new ArrayList<Product>();

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}

	// This should add the product object into the productList
	public void addProduct(Product product) {
		this.productList.add(product);
	}

	// This method should return the total number of products
	// for the given product category.

	public int countBasedOnCategory(String category) {
		int count = 0;
		for (Product product : this.productList) {
			if (product.getProductCategory().equalsIgnoreCase(category))
				count++;
		}
		return count;
	}

}
