import { Component, OnInit } from '@angular/core';
import {Music} from './music'
import { MusicService } from './music.service';
@Component({
  selector: 'app-show-albums',
  templateUrl: './show-albums.component.html',
  styleUrls: ['./show-albums.component.css']
})
export class ShowAlbumsComponent implements OnInit {
  musics:Music[];
  constructor(private musicService:MusicService) { }

  ngOnInit() {
    this.musics=this.musicService.getMusic();
  }
  deleteMusic(id){
    this.musicService.deleteMusic(id);
    this.musics=this.musicService.getMusic();
  }
}
