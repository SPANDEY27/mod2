import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ShowAlbumsComponent} from './music/show-albums.component';
import {HomeComponent} from './music/home.component';
import {SearchMusicComponent} from './music/search-music.component';
import {AddMusicComponent} from './music/add-music.component';

const routes: Routes = [
  {path:"show",component:ShowAlbumsComponent},
  {path:'',component:HomeComponent},
  {path:"search",component:SearchMusicComponent},
  {path:"add",component:AddMusicComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
