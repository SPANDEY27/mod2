import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { IProduct } from './product.interface';
import { Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  /**
   * @author lavanga
   * this is the service class called product service
   */
  products:IProduct[];
  constructor(private http:HttpClient) { 
    this.getProducts().subscribe(data=>this.products=data);
  }
  /**
   * getting the products to getproducts()
   */
  getProducts():Observable<IProduct[]>{
    return this.http.get<IProduct[]>("../../assets/db.json");
  }
  /**
   * getting all the data from products
   */
  getData(){
    return this.products;
  }
/**
 * setting the product details in setProduct()
 * @param products 
 */
  setProducts(products:IProduct[])
{
  this.products=products;
}
/**
 * deleting the product from the productList
 * @param id 
 */
deleteProduct(id:string){
 this.products=this.products.filter(s=>s.id!=id);
 }

}
