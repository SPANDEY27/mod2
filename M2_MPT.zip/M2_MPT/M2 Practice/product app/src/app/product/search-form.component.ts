import { Component, OnInit } from '@angular/core';
import { IProduct } from './product.interface';
import { ProductService } from './product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css']
})
export class SearchFormComponent implements OnInit {
  products:IProduct[];
  constructor(private productService:ProductService, private router:Router) { }
  
  ngOnInit() {
  }
  //Implementation of search method
  search(data){
    console.log(data);
    this.products=this.productService.getData();
    this.products=this.products.filter(product=>(product.name==data.any || product.category==data.any));
    console.log(this.products);
   }
}
