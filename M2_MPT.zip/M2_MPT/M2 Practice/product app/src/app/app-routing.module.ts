import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchFormComponent } from './product/search-form.component';
import { ProductListComponent } from './product/product-list.component';


const routes: Routes = [
  /**
   * setting the paths
   */
  {path: '', component: SearchFormComponent},
  {path: "productlist", component:ProductListComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
