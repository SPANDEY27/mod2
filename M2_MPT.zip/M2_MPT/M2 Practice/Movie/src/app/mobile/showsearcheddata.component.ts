import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showsearcheddata',
  templateUrl: './showsearcheddata.component.html',
  styleUrls: ['./showsearcheddata.component.css']
})
export class ShowsearcheddataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
