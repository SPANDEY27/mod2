import { Component, OnInit } from '@angular/core';
import { Music,MusicstoreService } from '../musicstore.service';

@Component({
  selector: 'app-addalbum',
  templateUrl: './addalbum.component.html',
  styleUrls: ['./addalbum.component.css']
})
export class AddalbumComponent implements OnInit {
  createdMusic:Music;
  createdFlag:boolean=false;
  service:MusicstoreService;
  constructor(service:MusicstoreService) 
  {
    this.service=service;
  }

  ngOnInit() {
  }

  add(data:any){
    this.createdMusic=new Music(data.AlbumID,data.Title,data.Artist,data.Price);
    this.service.add(this.createdMusic);
    alert("Album Added Succesfully");
    this.createdFlag=true;
   }
}
