import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddAlbumComponent } from './add-album/add-album.component';
import { AlbumListComponent } from './album-list/album-list.component';


const routes: Routes = [
  {
    path: '', redirectTo: '/albumlist', pathMatch: 'full'
  },
  {
    path: 'addalbum',
    component: AddAlbumComponent
  }, {
    path: 'albumlist',
    component: AlbumListComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
