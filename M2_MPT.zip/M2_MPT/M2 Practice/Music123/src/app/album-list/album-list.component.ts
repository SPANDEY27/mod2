import { Component, OnInit } from '@angular/core';
import { AlbumsService } from '../albums.service';

@Component({
  selector: 'app-album-list',
  templateUrl: './album-list.component.html',
  styleUrls: ['./album-list.component.css']
})
export class AlbumListComponent implements OnInit {

  albums:any[];
  constructor(private service:AlbumsService) { }

  ngOnInit() {
    this.albums = this.service.getAlbums();
  }
  Delete(value){
    alert('ARE YOU SURE u want to delete');
    this.albums=this.service.delete(value);
  }

  


}
