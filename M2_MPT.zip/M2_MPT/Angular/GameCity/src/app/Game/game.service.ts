import { Injectable } from '@angular/core';
import { Games } from './games';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class GameService {

  games: Games[];

  cardBalance: number = 600;

  constructor(private http: HttpClient) {
      this.populateGames().subscribe( data => this.games = data, error => console.log(error) );    
   }

  populateGames(): Observable<Games[]> {
    return this.http.get<Games[]>("../../assets/GameList.json");
  }

  getGames(): Games[] {
    return this.games;
  }

  getCardBalance(rate: number): number {
      this.cardBalance = this.cardBalance-rate;
      return this.cardBalance;
  }
  findBalance(){
    return this.cardBalance;
    }
}
