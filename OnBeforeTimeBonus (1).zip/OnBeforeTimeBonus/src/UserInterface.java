import java.util.Scanner;


public class UserInterface {
	
	
	
	public static void main(String a[]){
		Scanner sc=new Scanner(System.in);
		int noOfEmployees=sc.nextInt();
		String employees[]=new String[noOfEmployees];
		for(int i=0;i<noOfEmployees;i++){
			employees[i]=sc.next();
		}
		
		
		
	}

}
