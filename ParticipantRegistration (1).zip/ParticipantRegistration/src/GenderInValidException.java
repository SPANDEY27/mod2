//make the necessary change to make this class an Exception 
public class GenderInValidException  {
	
}
