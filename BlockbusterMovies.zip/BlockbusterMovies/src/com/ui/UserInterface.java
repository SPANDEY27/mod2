
package com.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.utility.Movie;

public class UserInterface {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		// Fill the UI code
		Movie movie = new Movie();
		System.out.println("Enter the number of movies");
		int noOfMovies = scan.nextInt();
		scan.nextLine();
		String movieName = null;
		int rating;
		int search;
		List<String> list = new ArrayList<String>();
		for (int i = 1; i <= noOfMovies; i++) {
			System.out.println("Enter the name of movie");
			movieName = scan.nextLine();

			System.out.println("Enter the rating of movie");
			rating = scan.nextInt();
			scan.nextLine();
			// adding the products to the map
			movie.addMovieDetails(movieName, rating);
		}
		for (Map.Entry<String, Integer> entry : movie.getMovieMap().entrySet()) {
			System.out.println(entry.getKey() + " " + entry.getValue());
		}
		System.out.println("Enter the rating to be searched");
		search = scan.nextInt();
		list = movie.findMovieBasedOnRating(search);
		for (String lists : list)
			System.out.println(lists);
		scan.close();
	}

}
