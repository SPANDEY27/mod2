package com.utility;

import java.util.*;

public class Movie {

	private Map<String, Integer> movieMap = new TreeMap<String, Integer>();;

	// movieMap=new HashMap<String, Integer>();
	public Map<String, Integer> getMovieMap() {
		return movieMap;
	}

	public void setMovieMap(Map<String, Integer> movieMap) {
		this.movieMap = movieMap;
	}

	// This method should add the movie name as key and rating as value into the
	// movieList map
	public void addMovieDetails(String movieName, int rating) {

		// Fill your code

		movieMap.put(movieName, rating);

	}

	/*
	 * This method should search the movie based on the rating and add those
	 * movies into the list and return the list. For example: If the map
	 * contains the key and value as:
	 * 
	 * Alita Battle Angel 1 Avengers Endgame 5 Avengers Infinity War 5
	 * Despicable Me 3 Incredibles 2 Interstellar 4
	 * 
	 * if the movie rating to be searched is 5, then the output should be
	 *
	 * Avengers Endgame Avengers Infinity War
	 * 
	 */
	public List<String> findMovieBasedOnRating(int rating) {

		// Fill your code

		List<String> lists = new ArrayList<String>();

		for (Map.Entry<String, Integer> entry : movieMap.entrySet()) {
			if (Objects.equals(rating, entry.getValue())) {
				lists.add(entry.getKey());
			}
		}
		return lists;
	}

}
