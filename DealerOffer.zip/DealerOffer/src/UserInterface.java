
import java.util.Scanner;


public class UserInterface {
	
	
	
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int noOfDealers=sc.nextInt();
		String dealer[]=new String[noOfDealers];
		for(int i=0;i<noOfDealers;i++){
			dealer[i]=sc.next();
		}		
                 //Fill the Code here
		int p;
		double maxd=99999.0,discount=0.0;
		double price = 0;
		String []productName = new String[noOfDealers];
		double[] maxDiscountprice=new double[noOfDealers];
		for(int i=0;i<noOfDealers;i++){
			p=dealer[i].lastIndexOf(',')+1;
			discount=Double.parseDouble(dealer[i].substring(p));
			int p2=dealer[i].indexOf(',')+1;
			price=Double.parseDouble(dealer[i].substring(p2, p-1));	
			
			maxDiscountprice[i]=price-((discount/100)*price);
			productName[i]=dealer[i].substring(0,p2-1);
		}
		double maxdis=maxDiscountprice[0];
		for(int i=0;i<noOfDealers;i++){
			if(maxDiscountprice[i]<maxdis){
				maxdis=maxDiscountprice[i];
				
			}
				
		}
		for(int i=0;i<noOfDealers;i++){
			if(maxDiscountprice[i]==maxdis){
				System.out.println(productName[i]+" "+maxDiscountprice[i]);
			}
		}
		
		
	}

}



