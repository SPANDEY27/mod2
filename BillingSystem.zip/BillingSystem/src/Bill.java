


public class Bill {

	private String itemName;
	private int quantity;
	private float price;
	
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) throws QuantityInValidException{
		if (quantity > 0){
			this.quantity = quantity;
			System.out.println("Valid Quantity");
		}
		else{
			//fill the code
			if(quantity < 0){
				throw new QuantityInValidException("Invalid Quantity");
			}
			
		}
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
}
