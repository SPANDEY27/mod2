
public class QuantityInValidException  extends Exception{
	
	public QuantityInValidException(String message) {
		super(message);
	}

}
