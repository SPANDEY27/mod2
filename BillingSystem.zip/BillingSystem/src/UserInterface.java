import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Item Name");
		String name=sc.nextLine();
		System.out.println("Enter Unit Price");
		float price=sc.nextFloat();
		System.out.println("Enter Quantity");
		int qty = sc.nextInt();

		Bill bobj = new Bill();
		bobj.setItemName(name);
		bobj.setPrice(price);
		// fill the code
		try{
			bobj.setQuantity(qty);
		}catch(QuantityInValidException e){
			System.out.println("Invalid Quantity");
			e.printStackTrace();
		}
	
	}

}