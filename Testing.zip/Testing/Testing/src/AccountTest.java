import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;


public class AccountTest {
	@Test
	public void youvar1(){
		Account accvar3 = new Account(101, "savings", 0);
		boolean actual = accvar3.deposit(-100);
		assertFalse(actual);
	}
	
	@Test
	public void youvar2(){
		Account accvar4 = new Account(102, "savings", 0);
		boolean actual = accvar4.deposit(1526);
		assertTrue(actual);
	}	
	

}
